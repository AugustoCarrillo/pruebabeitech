﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class OrderContext : DbContext
    {

        public OrderContext() : base("name=ORderContext")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<OrderContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public System.Data.Entity.DbSet<WebApi.Models.Order> Order { get; set; }
    }
}
