﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class CustomerContext : DbContext
    {

        public CustomerContext() : base("name=CustomerContext")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<CustomerContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public System.Data.Entity.DbSet<WebApi.Models.Customer> Customer { get; set; }

    }
}
