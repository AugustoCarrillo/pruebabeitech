﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class Order
    {
        
        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public string DeliveryAddress { get; set; }
        public DateTime Date { get; set; }
        public virtual Customer Cliente { get; set; }

        [ForeignKey("OrderId")]
        public virtual ICollection<OrderDetail> Detalles { get; set; } 
    }
}