﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class ProductContext : DbContext
    {
        public ProductContext() : base("name=ProductContext")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<ProductContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public System.Data.Entity.DbSet<WebApi.Models.Product> Product { get; set; }
    }
}
