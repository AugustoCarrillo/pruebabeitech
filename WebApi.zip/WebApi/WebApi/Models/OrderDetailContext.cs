﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class OrderDetailContext : DbContext
    {
        public OrderDetailContext() : base("name=OrderDetailContext")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<OrderDetailContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public System.Data.Entity.DbSet<WebApi.Models.OrderDetail> OrderDetail { get; set; } 
    }
}
