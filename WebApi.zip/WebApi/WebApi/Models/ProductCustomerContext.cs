﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class ProductCustomerContext : DbContext
    {

        public ProductCustomerContext() : base("name=ProductCustomerContext")
        {
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            Database.SetInitializer<ProductCustomerContext>(null);
            base.OnModelCreating(modelBuilder);
        }
        public System.Data.Entity.DbSet<WebApi.Models.ProductCustomer> ProductCustomers { get; set; }
    }
}
