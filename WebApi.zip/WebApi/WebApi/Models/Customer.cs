﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }

       /* public int PID;
        public string PN;
        public int PP;

        public List<Product> Productos;*/
        //public virtual ICollection<Product> Productos { get; set; }
        public virtual ICollection<ProductCustomer> Productos { get; set; }
    }
}