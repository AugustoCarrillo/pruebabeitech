﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class ProductController : ApiController
    {
        private ProductContext db = new ProductContext();

        [Route("api/Products")]
        [HttpGet]
        [AllowAnonymous]
        public IQueryable<Product> GetProducts()
        {
            return db.Product;
        }  
    }
}