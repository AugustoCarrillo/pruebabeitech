﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class OrderController : ApiController
    {
        private OrderContext db = new OrderContext();

        [Route("api/Orders")]
        [HttpGet]
        [AllowAnonymous]
        public IQueryable<Order> GetOrders()
        {
            return db.Order.SqlQuery("SELECT Orders.*, Customers.Name Nombre FROM Orders INNER JOIN Customers ON Orders.CustomerId = Customers.CustomerId").AsQueryable(); ;
        }
        
    }
}