﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class CustomerController : ApiController
    {
        private CustomerContext db = new CustomerContext();

        [Route("api/Customers")]
        [HttpGet]
        [AllowAnonymous]
        public IQueryable<Customer> GetCustomers()
        {
            return db.Customer;
        }        
    }
}