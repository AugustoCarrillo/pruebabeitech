﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApi.Models;

namespace WebApi.Controllers
{
    public class ProductCustomersController : ApiController
    {
        private ProductCustomerContext db = new ProductCustomerContext();

        [Route("api/ProdCustomers")]
        [HttpGet]
        [AllowAnonymous]
        public Array ProdCustomers()
        {
            return db.Database.SqlQuery<ProdCustomer>("SELECT c.Name Nombre, COUNT(*) Cantidad FROM ProductCustomers pc INNER JOIN Customers c ON pc.CustomerId = c.CustomerId GROUP BY c.Name").ToArray();
        }

        [Route("api/BestSeller")]
        [HttpGet]
        [AllowAnonymous]
        public Array BestSeller()
        {
            return db.Database.SqlQuery<ProdCustomer>("SELECT p.Name Nombre, COUNT(*) Cantidad FROM OrderDetails od INNER JOIN Products p ON od.ProductId = p.ProductId GROUP BY p.Name").ToArray();
        }
    }
}